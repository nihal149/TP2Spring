package dao;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class DaoImplTest {
    @Test
    public void testGetValue() {
        IDao dao = new DaoImpl();
        assertEquals(100.0, dao.getValue(), 0.01);
    }
}
