package metier;

import dao.IDao;
import dao.DaoImpl;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import static org.junit.Assert.assertEquals;

public class MetierImplTest {
    @Test
    public void testCalcul() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("dao");
        context.refresh();

        IMetier metier = context.getBean(MetierImpl.class);
        assertEquals(200.0, metier.calcul(), 0.01);
    }
}
