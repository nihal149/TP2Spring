package metier;

public interface IMetier {
    double calcul();
}
